Welcome to ACRI Programming Language

ACRI is a beginner-friendly language for AI tasks.
You can use commands like:

display("Hello world")
chat("What is AI?")
image("a robot")
translate("Namaste", to="English")

HOW TO USE:
1. Open 'interpreter.js' with Node.js (Ask a developer or use online JS tool)
2. Write your code in 'sample.acri'
3. Run to see output

This is for learning and testing AI ideas.

Created by: Biswarup Das
